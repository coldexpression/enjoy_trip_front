<template>
  <footer class="footer">footer</footer>
</template>

<style scoped>
@import "../assets/css/include.css";
</style>
